import { pgTable, text, serial, integer, boolean, timestamp, jsonb, uuid, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  mobile: text("mobile").unique(),
  email: text("email").unique(),
  password: text("password"),
  role: text("role").notNull().default("OPERATOR"), // ADMIN, STAFF, OPERATOR
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  nameEn: text("name_en").notNull(),
  nameBn: text("name_bn").notNull(),
  descriptionEn: text("description_en").notNull(),
  descriptionBn: text("description_bn").notNull(),
  price: integer("price").notNull(), // in cents/paise
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notices = pgTable("notices", {
  id: serial("id").primaryKey(),
  titleEn: text("title_en").notNull(),
  titleBn: text("title_bn").notNull(),
  contentEn: text("content_en").notNull(),
  contentBn: text("content_bn").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const requests = pgTable("requests", {
  id: serial("id").primaryKey(),
  applicationNumber: text("application_number").notNull().unique(), // e.g., NZ12345
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  serviceId: integer("service_id").notNull(),
  amount: integer("amount").notNull(),
  paymentMethod: text("payment_method").default("UPI"),
  utrNumber: text("utr_number"),
  status: text("status").notNull().default("SUBMITTED"), // SUBMITTED, VERIFIED, PAYMENT_PENDING, PROCESSING, COMPLETED, DELIVERED
  assignedOperatorId: integer("assigned_operator_id"),
  documents: jsonb("documents").$type<string[]>(), // Array of file URLs
  remarks: text("remarks"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const otpVerifications = pgTable("otp_verifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  phoneNumber: varchar("phone_number", { length: 15 }).notNull(),
  otpHash: text("otp_hash").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  attemptCount: integer("attempt_count").default(0),
  resendCount: integer("resend_count").default(0),
  lastSentAt: timestamp("last_sent_at"),
  ipAddress: varchar("ip_address", { length: 45 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// === BASE SCHEMAS ===
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertServiceSchema = createInsertSchema(services).omit({ id: true, createdAt: true });
export const insertNoticeSchema = createInsertSchema(notices).omit({ id: true, createdAt: true });
export const insertRequestSchema = createInsertSchema(requests).omit({ id: true, createdAt: true, updatedAt: true, applicationNumber: true });

// === EXPLICIT API CONTRACT TYPES ===

// Users
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateUserRequest = Partial<InsertUser>;

// Services
export type Service = typeof services.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type UpdateServiceRequest = Partial<InsertService>;

// Notices
export type Notice = typeof notices.$inferSelect;
export type InsertNotice = z.infer<typeof insertNoticeSchema>;
export type UpdateNoticeRequest = Partial<InsertNotice>;

// Requests
export type Request = typeof requests.$inferSelect;
export type InsertRequest = z.infer<typeof insertRequestSchema>;
export type UpdateRequestPayload = Partial<InsertRequest> & { status?: string };

// Auth
export const loginSchema = z.object({
  identifier: z.string(), // email or mobile
  password: z.string().optional(), // for email login
  otp: z.string().optional(), // for mobile login
  type: z.enum(["email", "mobile"]),
});
export type LoginPayload = z.infer<typeof loginSchema>;

export const generateOtpSchema = z.object({
  mobile: z.string(),
});
export type GenerateOtpPayload = z.infer<typeof generateOtpSchema>;
