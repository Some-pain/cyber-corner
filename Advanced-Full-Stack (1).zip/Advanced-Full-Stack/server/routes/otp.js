import express from "express"
import axios from "axios"
import bcrypt from "bcrypt"
import crypto from "crypto"
import rateLimit from "express-rate-limit"
import { db } from "../database.js"
import { otpVerifications } from "../../shared/schema.js"

const router = express.Router()

const otpLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 3
})

router.post("/send", otpLimiter, async (req, res) => {
  const { phone } = req.body
  const otp = crypto.randomInt(100000, 999999).toString()
  const hash = await bcrypt.hash(otp, 10)

  await db.insert(otpVerifications).values({
    phoneNumber: phone,
    otpHash: hash,
    expiresAt: new Date(Date.now() + 5 * 60 * 1000),
    lastSentAt: new Date(),
    resendCount: 1,
    attemptCount: 0,
    ipAddress: req.ip
  })

  await axios.post(
    "https://www.fast2sms.com/dev/bulkV2",
    {
      route: "otp",
      variables_values: otp,
      numbers: phone
    },
    {
      headers: {
        authorization: process.env.FAST2SMS_API_KEY
      }
    }
  )

  res.json({ success: true })
})

export default router