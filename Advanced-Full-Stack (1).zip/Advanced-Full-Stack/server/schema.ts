import {
  pgTable,
  uuid,
  varchar,
  text,
  timestamp,
  integer,
  boolean,
  pgEnum
} from "drizzle-orm/pg-core"

/* ===============================
   ENUMS
=================================*/

// User Roles (Admin / Operator / Agent / Citizen)
export const roleEnum = pgEnum("role", [
  "admin",
  "operator",
  "agent",
  "citizen"
])

// Service Status
export const serviceStatusEnum = pgEnum("service_status", [
  "pending",
  "processing",
  "approved",
  "rejected",
  "completed"
])

// Payment Status
export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "success",
  "failed"
])

/* ===============================
   USERS TABLE
=================================*/

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),

  name: varchar("name", { length: 100 }),

  phoneNumber: varchar("phone_number", { length: 15 })
    .notNull()
    .unique(),

  email: varchar("email", { length: 150 }),

  role: roleEnum("role").default("citizen"),

  isVerified: boolean("is_verified").default(false),

  createdAt: timestamp("created_at").defaultNow()
})

/* ===============================
   OTP VERIFICATION TABLE
=================================*/

export const otpVerifications = pgTable("otp_verifications", {
  id: uuid("id").defaultRandom().primaryKey(),

  phoneNumber: varchar("phone_number", { length: 15 }).notNull(),

  otpHash: text("otp_hash").notNull(),

  expiresAt: timestamp("expires_at").notNull(),

  attemptCount: integer("attempt_count").default(0),

  resendCount: integer("resend_count").default(0),

  lastSentAt: timestamp("last_sent_at"),

  ipAddress: varchar("ip_address", { length: 45 }),

  createdAt: timestamp("created_at").defaultNow()
})

/* ===============================
   SERVICE REQUESTS (CSC WORKFLOW)
=================================*/

export const serviceRequests = pgTable("service_requests", {
  id: uuid("id").defaultRandom().primaryKey(),

  userId: uuid("user_id")
    .references(() => users.id)
    .notNull(),

  serviceName: varchar("service_name", { length: 150 }).notNull(),

  status: serviceStatusEnum("status").default("pending"),

  description: text("description"),

  createdAt: timestamp("created_at").defaultNow()
})

/* ===============================
   PAYMENTS TABLE
=================================*/

export const payments = pgTable("payments", {
  id: uuid("id").defaultRandom().primaryKey(),

  userId: uuid("user_id")
    .references(() => users.id)
    .notNull(),

  serviceRequestId: uuid("service_request_id")
    .references(() => serviceRequests.id),

  amount: integer("amount").notNull(),

  utrNumber: varchar("utr_number", { length: 50 }),

  status: paymentStatusEnum("status").default("pending"),

  createdAt: timestamp("created_at").defaultNow()
})

/* ===============================
   AUDIT LOGS (Government Level)
=================================*/

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),

  userId: uuid("user_id")
    .references(() => users.id),

  action: varchar("action", { length: 200 }).notNull(),

  metadata: text("metadata"),

  ipAddress: varchar("ip_address", { length: 45 }),

  createdAt: timestamp("created_at").defaultNow()
})