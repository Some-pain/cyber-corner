import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage.js";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Auth routes (Simulated)
  app.post(api.auth.generateOtp.path, async (req, res) => {
    try {
      const input = api.auth.generateOtp.input.parse(req.body);
      console.log(`Generated OTP for ${input.mobile}: 123456`);
      res.json({ message: "OTP sent successfully" });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.auth.login.path, async (req, res) => {
    try {
      const input = api.auth.login.input.parse(req.body);
      let user;

      if (input.type === "mobile" && input.otp === "123456") {
        user = await storage.getUserByMobile(input.identifier);
      } else if (input.type === "email") {
        user = await storage.getUserByEmail(input.identifier);
        // Simple password check for simulation
        if (user && user.password !== input.password) {
          user = undefined;
        }
      }

      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      res.json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Users routes
  app.get(api.users.list.path, async (req, res) => {
    const users = await storage.getUsers();
    res.json(users);
  });

  app.post(api.users.create.path, async (req, res) => {
    try {
      const input = api.users.create.input.parse(req.body);
      const user = await storage.createUser(input);
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.put(api.users.update.path, async (req, res) => {
    try {
      const input = api.users.update.input.parse(req.body);
      const user = await storage.updateUser(Number(req.params.id), input);
      if (!user) return res.status(404).json({ message: "User not found" });
      res.json(user);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  // Services
  app.get(api.services.list.path, async (req, res) => {
    const services = await storage.getServices();
    res.json(services);
  });
  
  app.post(api.services.create.path, async (req, res) => {
    try {
      const input = api.services.create.input.parse(req.body);
      const service = await storage.createService(input);
      res.status(201).json(service);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.put(api.services.update.path, async (req, res) => {
    try {
      const input = api.services.update.input.parse(req.body);
      const service = await storage.updateService(Number(req.params.id), input);
      if (!service) return res.status(404).json({ message: "Service not found" });
      res.json(service);
    } catch(err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.delete(api.services.delete.path, async (req, res) => {
    await storage.deleteService(Number(req.params.id));
    res.status(204).end();
  });

  // Notices
  app.get(api.notices.list.path, async (req, res) => {
    const notices = await storage.getNotices();
    res.json(notices);
  });

  app.post(api.notices.create.path, async (req, res) => {
    try {
      const input = api.notices.create.input.parse(req.body);
      const notice = await storage.createNotice(input);
      res.status(201).json(notice);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.put(api.notices.update.path, async (req, res) => {
    try {
      const input = api.notices.update.input.parse(req.body);
      const notice = await storage.updateNotice(Number(req.params.id), input);
      if (!notice) return res.status(404).json({ message: "Notice not found" });
      res.json(notice);
    } catch(err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.delete(api.notices.delete.path, async (req, res) => {
    await storage.deleteNotice(Number(req.params.id));
    res.status(204).end();
  });

  // Requests
  app.get(api.requests.list.path, async (req, res) => {
    const requests = await storage.getRequests();
    res.json(requests);
  });

  app.get(api.requests.get.path, async (req, res) => {
    const request = await storage.getRequest(Number(req.params.id));
    if (!request) return res.status(404).json({ message: "Request not found" });
    res.json(request);
  });

  app.post(api.requests.create.path, async (req, res) => {
    try {
      // Extend the schema internally so we can parse numbers passed as strings from multipart/form-data if needed
      // Or if JSON body is used, the frontend must send serviceId and amount as numbers. 
      // The schema z.coerce.number() handles it!
      const input = api.requests.create.input.parse(req.body);
      const request = await storage.createRequest(input);
      res.status(201).json(request);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.put(api.requests.update.path, async (req, res) => {
    try {
      const input = api.requests.update.input.parse(req.body);
      const request = await storage.updateRequest(Number(req.params.id), input);
      if (!request) return res.status(404).json({ message: "Request not found" });
      res.json(request);
    } catch(err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal error" });
    }
  });

  // Upload (Simulated)
  app.post(api.upload.file.path, (req, res) => {
    res.json({ url: "/simulated-upload-path.pdf" });
  });

  // Seed DB
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const users = await storage.getUsers();
  if (users.length === 0) {
    await storage.createUser({ name: "Admin User", mobile: "9999999999", email: "admin@netzone.com", password: "admin", role: "ADMIN", isVerified: true });
    await storage.createUser({ name: "Staff Member", mobile: "8888888888", email: "staff@netzone.com", password: "staff", role: "STAFF", isVerified: true });
    await storage.createUser({ name: "Operator One", mobile: "7777777777", email: "operator@netzone.com", password: "operator", role: "OPERATOR", isVerified: true });

    await storage.createService({ nameEn: "PAN Card Registration", nameBn: "প্যান কার্ড নিবন্ধন", descriptionEn: "Apply for a new PAN card", descriptionBn: "নতুন প্যান কার্ডের জন্য আবেদন করুন", price: 20000, isActive: true });
    await storage.createService({ nameEn: "Aadhaar Update", nameBn: "আধার আপডেট", descriptionEn: "Update Name, Address or DOB", descriptionBn: "নাম, ঠিকানা বা জন্ম তারিখ আপডেট করুন", price: 10000, isActive: true });

    await storage.createNotice({ titleEn: "Server Maintenance", titleBn: "সার্ভার রক্ষণাবেক্ষণ", contentEn: "The portal will be down for maintenance on Sunday 2 AM to 4 AM.", contentBn: "রবিবার রাত ২টা থেকে ৪টা পর্যন্ত পোর্টাল রক্ষণাবেক্ষণের জন্য বন্ধ থাকবে।", isActive: true });

    await storage.createRequest({ customerName: "Rahul Sharma", phone: "9876543210", serviceId: 1, amount: 20000, paymentMethod: "UPI", status: "VERIFIED", utrNumber: "UPI123456789", assignedOperatorId: 2, remarks: "Documents look good." });
  }
}