import { db } from "./database.js";
import {
  users, services, notices, requests,
  type User, type InsertUser, type UpdateUserRequest,
  type Service, type InsertService, type UpdateServiceRequest,
  type Notice, type InsertNotice, type UpdateNoticeRequest,
  type Request as RequestModel, type InsertRequest, type UpdateRequestPayload
} from "@shared/schema.js";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByMobile(mobile: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: UpdateUserRequest): Promise<User>;

  // Services
  getServices(): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, updates: UpdateServiceRequest): Promise<Service>;
  deleteService(id: number): Promise<void>;

  // Notices
  getNotices(): Promise<Notice[]>;
  getNotice(id: number): Promise<Notice | undefined>;
  createNotice(notice: InsertNotice): Promise<Notice>;
  updateNotice(id: number, updates: UpdateNoticeRequest): Promise<Notice>;
  deleteNotice(id: number): Promise<void>;

  // Requests
  getRequests(): Promise<RequestModel[]>;
  getRequest(id: number): Promise<RequestModel | undefined>;
  createRequest(request: InsertRequest): Promise<RequestModel>;
  updateRequest(id: number, updates: UpdateRequestPayload): Promise<RequestModel>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  async getUserByMobile(mobile: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.mobile, mobile));
    return user;
  }
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  async updateUser(id: number, updates: UpdateUserRequest): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async getServices(): Promise<Service[]> {
    return await db.select().from(services);
  }
  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }
  async createService(insertService: InsertService): Promise<Service> {
    const [service] = await db.insert(services).values(insertService).returning();
    return service;
  }
  async updateService(id: number, updates: UpdateServiceRequest): Promise<Service> {
    const [service] = await db.update(services).set(updates).where(eq(services.id, id)).returning();
    return service;
  }
  async deleteService(id: number): Promise<void> {
    await db.delete(services).where(eq(services.id, id));
  }

  async getNotices(): Promise<Notice[]> {
    return await db.select().from(notices);
  }
  async getNotice(id: number): Promise<Notice | undefined> {
    const [notice] = await db.select().from(notices).where(eq(notices.id, id));
    return notice;
  }
  async createNotice(insertNotice: InsertNotice): Promise<Notice> {
    const [notice] = await db.insert(notices).values(insertNotice).returning();
    return notice;
  }
  async updateNotice(id: number, updates: UpdateNoticeRequest): Promise<Notice> {
    const [notice] = await db.update(notices).set(updates).where(eq(notices.id, id)).returning();
    return notice;
  }
  async deleteNotice(id: number): Promise<void> {
    await db.delete(notices).where(eq(notices.id, id));
  }

  async getRequests(): Promise<RequestModel[]> {
    return await db.select().from(requests);
  }
  async getRequest(id: number): Promise<RequestModel | undefined> {
    const [request] = await db.select().from(requests).where(eq(requests.id, id));
    return request;
  }
  async createRequest(insertRequest: InsertRequest): Promise<RequestModel> {
    const applicationNumber = `NZ${Math.floor(10000 + Math.random() * 90000)}`;
    const [request] = await db.insert(requests).values({ ...insertRequest, applicationNumber }).returning();
    return request;
  }
  async updateRequest(id: number, updates: UpdateRequestPayload): Promise<RequestModel> {
    const [request] = await db.update(requests).set({ ...updates, updatedAt: new Date() }).where(eq(requests.id, id)).returning();
    return request;
  }
}

export const storage = new DatabaseStorage();