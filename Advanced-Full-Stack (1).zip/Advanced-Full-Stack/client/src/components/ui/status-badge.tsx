import { Badge } from "@/components/ui/badge";

export type RequestStatus = "SUBMITTED" | "VERIFIED" | "PAYMENT_PENDING" | "PROCESSING" | "COMPLETED" | "DELIVERED";

export function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string, classes: string }> = {
    "SUBMITTED": { label: "Submitted", classes: "bg-gray-100 text-gray-800 border-gray-200" },
    "VERIFIED": { label: "Verified", classes: "bg-blue-100 text-blue-800 border-blue-200" },
    "PAYMENT_PENDING": { label: "Payment Pending", classes: "bg-yellow-100 text-yellow-800 border-yellow-200" },
    "PROCESSING": { label: "Processing", classes: "bg-purple-100 text-purple-800 border-purple-200" },
    "COMPLETED": { label: "Completed", classes: "bg-green-100 text-green-800 border-green-200" },
    "DELIVERED": { label: "Delivered", classes: "bg-teal-100 text-teal-800 border-teal-200" },
  };

  const current = config[status] || { label: status, classes: "bg-gray-100 text-gray-800" };

  return (
    <Badge variant="outline" className={`font-medium ${current.classes}`}>
      {current.label}
    </Badge>
  );
}
