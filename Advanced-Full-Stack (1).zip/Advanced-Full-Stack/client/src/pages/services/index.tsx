import { useState } from "react";
import { AppLayout } from "@/components/layout/app-layout";
import { useServices, useCreateService } from "@/hooks/use-services";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Plus, Settings2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function ServicesPage() {
  const { data: services = [], isLoading } = useServices();
  const createMutation = useCreateService();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  const [formData, setFormData] = useState({
    nameEn: "", nameBn: "", descriptionEn: "", descriptionBn: "", price: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMutation.mutateAsync({
        ...formData,
        price: parseInt(formData.price) * 100, // convert to paise
        isActive: true
      });
      toast({ title: "Service created" });
      setIsOpen(false);
      setFormData({ nameEn: "", nameBn: "", descriptionEn: "", descriptionBn: "", price: "" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold font-display">Services Directory</h1>
            <p className="text-muted-foreground">Manage offered CSC services</p>
          </div>
          
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="gov-gradient hover-elevate">
                <Plus className="w-4 h-4 mr-2" /> Add Service
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Add New Service</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Name (English)</Label>
                    <Input required value={formData.nameEn} onChange={e => setFormData({...formData, nameEn: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Name (Bengali)</Label>
                    <Input required value={formData.nameBn} onChange={e => setFormData({...formData, nameBn: e.target.value})} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Description (English)</Label>
                  <Textarea required value={formData.descriptionEn} onChange={e => setFormData({...formData, descriptionEn: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Description (Bengali)</Label>
                  <Textarea required value={formData.descriptionBn} onChange={e => setFormData({...formData, descriptionBn: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Base Price (₹)</Label>
                  <Input type="number" required min="0" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending} className="w-full gov-gradient">
                    {createMutation.isPending ? "Saving..." : "Save Service"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="gov-card border-none shadow-md">
          <Table>
            <TableHeader className="bg-secondary/40">
              <TableRow>
                <TableHead className="w-12"><Settings2 className="w-4 h-4 text-muted-foreground" /></TableHead>
                <TableHead className="font-semibold">Service Name</TableHead>
                <TableHead className="font-semibold">Description</TableHead>
                <TableHead className="text-right font-semibold">Base Price</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8">Loading...</TableCell></TableRow>
              ) : services.length === 0 ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8">No services configured.</TableCell></TableRow>
              ) : (
                services.map((svc) => (
                  <TableRow key={svc.id} className="hover:bg-secondary/10">
                    <TableCell><div className="w-2 h-2 rounded-full bg-green-500" title="Active"></div></TableCell>
                    <TableCell>
                      <p className="font-semibold">{svc.nameEn}</p>
                      <p className="text-xs text-muted-foreground">{svc.nameBn}</p>
                    </TableCell>
                    <TableCell className="max-w-xs truncate text-sm text-muted-foreground">
                      {svc.descriptionEn}
                    </TableCell>
                    <TableCell className="text-right font-mono font-medium">
                      ₹{(svc.price / 100).toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>
      </div>
    </AppLayout>
  );
}
