import { useState } from "react";
import { AppLayout } from "@/components/layout/app-layout";
import { useNotices, useCreateNotice, useDeleteNotice } from "@/hooks/use-notices";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function NoticesPage() {
  const { data: notices = [], isLoading } = useNotices();
  const createMutation = useCreateNotice();
  const deleteMutation = useDeleteNotice();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  const [formData, setFormData] = useState({ titleEn: "", titleBn: "", contentEn: "", contentBn: "" });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMutation.mutateAsync({ ...formData, isActive: true });
      toast({ title: "Notice published" });
      setIsOpen(false);
      setFormData({ titleEn: "", titleBn: "", contentEn: "", contentBn: "" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if(confirm("Delete this notice?")) {
      await deleteMutation.mutateAsync(id);
      toast({ title: "Notice deleted" });
    }
  }

  return (
    <AppLayout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <div className="flex justify-between items-center border-b border-border pb-4">
          <div>
            <h1 className="text-2xl font-bold font-display flex items-center gap-2">
              <Bell className="text-primary" /> Official Notices
            </h1>
          </div>
          
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="gov-gradient hover-elevate">
                <Plus className="w-4 h-4 mr-2" /> New Notice
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Publish Notice</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Title (English)</Label>
                  <Input required value={formData.titleEn} onChange={e => setFormData({...formData, titleEn: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Content (English)</Label>
                  <Textarea required value={formData.contentEn} onChange={e => setFormData({...formData, contentEn: e.target.value})} className="h-24" />
                </div>
                <div className="h-px bg-border my-4" />
                <div className="space-y-2">
                  <Label>Title (Bengali)</Label>
                  <Input required value={formData.titleBn} onChange={e => setFormData({...formData, titleBn: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Content (Bengali)</Label>
                  <Textarea required value={formData.contentBn} onChange={e => setFormData({...formData, contentBn: e.target.value})} className="h-24" />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending} className="gov-gradient">
                    Publish
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {isLoading ? (
            <p className="text-muted-foreground text-center py-8">Loading notices...</p>
          ) : notices.length === 0 ? (
            <Card className="bg-secondary/30 border-dashed"><CardContent className="py-12 text-center text-muted-foreground">No active notices.</CardContent></Card>
          ) : (
            notices.map((notice) => (
              <Card key={notice.id} className="gov-card border-l-4 border-l-primary hover:border-l-accent transition-colors">
                <CardHeader className="py-4 flex flex-row items-start justify-between space-y-0">
                  <div>
                    <CardTitle className="text-lg text-primary">{notice.titleEn}</CardTitle>
                    <p className="text-xs text-muted-foreground mt-1">
                      Published on {notice.createdAt ? format(new Date(notice.createdAt), 'PPP') : 'Unknown'}
                    </p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(notice.id)} className="text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </CardHeader>
                <CardContent className="py-0 pb-4 text-sm">
                  <p className="text-foreground leading-relaxed">{notice.contentEn}</p>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </AppLayout>
  );
}
