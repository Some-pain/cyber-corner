import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useRequests } from "@/hooks/use-requests";
import { useI18n } from "@/lib/i18n";
import { FileText, Clock, CheckCircle, IndianRupee } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format, subDays } from "date-fns";

export default function Dashboard() {
  const { t } = useI18n();
  const { data: requests = [], isLoading } = useRequests();

  const totalRequests = requests.length;
  const pendingRequests = requests.filter(r => ['SUBMITTED', 'VERIFIED', 'PAYMENT_PENDING'].includes(r.status)).length;
  const completedRequests = requests.filter(r => ['COMPLETED', 'DELIVERED'].includes(r.status)).length;
  const totalRevenue = requests.filter(r => r.status !== 'SUBMITTED').reduce((acc, curr) => acc + curr.amount, 0) / 100;

  // Mock chart data based on last 7 days
  const chartData = Array.from({ length: 7 }).map((_, i) => {
    const d = subDays(new Date(), 6 - i);
    const dateStr = format(d, 'MMM dd');
    return {
      name: dateStr,
      requests: Math.floor(Math.random() * 20) + 5,
    };
  });

  const StatCard = ({ title, value, icon: Icon, colorClass }: any) => (
    <Card className="gov-card hover-elevate">
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          <h3 className="text-3xl font-display font-bold text-foreground">{value}</h3>
        </div>
        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${colorClass}`}>
          <Icon size={24} />
        </div>
      </CardContent>
    </Card>
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold font-display">{t("dashboard")}</h1>
          <p className="text-muted-foreground">Overview of portal activities</p>
        </div>

        {isLoading ? (
          <div className="h-64 flex items-center justify-center text-muted-foreground">Loading dashboard data...</div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <StatCard 
                title={t("total_requests")} 
                value={totalRequests} 
                icon={FileText} 
                colorClass="bg-blue-100 text-blue-600" 
              />
              <StatCard 
                title={t("pending_actions")} 
                value={pendingRequests} 
                icon={Clock} 
                colorClass="bg-yellow-100 text-yellow-600" 
              />
              <StatCard 
                title="Completed" 
                value={completedRequests} 
                icon={CheckCircle} 
                colorClass="bg-green-100 text-green-600" 
              />
              <StatCard 
                title={t("revenue")} 
                value={`₹${totalRevenue.toLocaleString('en-IN')}`} 
                icon={IndianRupee} 
                colorClass="bg-purple-100 text-purple-600" 
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="col-span-1 lg:col-span-2 gov-card">
                <CardHeader>
                  <CardTitle>Recent Activity (7 Days)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} dy={10} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} />
                        <Tooltip 
                          cursor={{ fill: '#f3f4f6' }}
                          contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                        />
                        <Bar dataKey="requests" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={40} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="gov-card">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                    <h4 className="font-semibold text-sm">New Notice Published</h4>
                    <p className="text-xs text-muted-foreground mt-1">System update scheduled for tomorrow 2 AM.</p>
                  </div>
                  <div className="p-4 rounded-lg bg-yellow-50 border border-yellow-100">
                    <h4 className="font-semibold text-sm text-yellow-800">Pending Approvals</h4>
                    <p className="text-xs text-yellow-700 mt-1">You have {pendingRequests} applications waiting for review.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </AppLayout>
  );
}
