import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ShieldCheck, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const { login, isLoggingIn, user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");

  if (user) {
    setLocation("/dashboard");
    return null;
  }

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login({ type: "email", identifier, password });
      toast({ title: "Login successful" });
    } catch (err: any) {
      toast({ title: "Login failed", description: err.message, variant: "destructive" });
    }
  };

  const handleMobileLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login({ type: "mobile", identifier, otp });
      toast({ title: "Login successful" });
    } catch (err: any) {
      toast({ title: "Login failed", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-secondary/50 flex items-center justify-center p-4">
      <div className="absolute inset-0 z-0 bg-[url('https://images.unsplash.com/photo-1579548122080-c35fd6820ecb?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-5"></div>
      
      <Card className="w-full max-w-md z-10 shadow-2xl border-primary/10 bg-background/95 backdrop-blur-sm">
        <CardHeader className="space-y-3 pb-6 text-center">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center text-primary-foreground shadow-lg shadow-primary/25 mb-2">
            <ShieldCheck size={32} />
          </div>
          <CardTitle className="text-2xl font-display font-bold text-foreground">NETZONE Portal</CardTitle>
          <CardDescription className="text-base">
            Digital Service Center Authorization
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="email" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="email">Email / Staff</TabsTrigger>
              <TabsTrigger value="mobile">Mobile OTP</TabsTrigger>
            </TabsList>
            
            <TabsContent value="email">
              <form onSubmit={handleEmailLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="admin@netzone.gov"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    required
                    className="bg-card"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input 
                    id="password" 
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="bg-card"
                  />
                </div>
                <Button type="submit" className="w-full gov-gradient hover-elevate" disabled={isLoggingIn}>
                  {isLoggingIn ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Sign In to Portal"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="mobile">
              <form onSubmit={handleMobileLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="mobile">Mobile Number</Label>
                  <div className="flex gap-2">
                    <Input 
                      id="mobile" 
                      placeholder="9876543210"
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      required
                      className="bg-card"
                    />
                    <Button type="button" variant="outline" onClick={() => toast({ title: "OTP Sent (Simulated 1234)" })}>
                      Send OTP
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="otp">Enter OTP</Label>
                  <Input 
                    id="otp" 
                    placeholder="1234"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    required
                    className="bg-card text-center tracking-[0.5em] font-mono text-lg"
                    maxLength={4}
                  />
                </div>
                <Button type="submit" className="w-full gov-gradient hover-elevate" disabled={isLoggingIn}>
                  {isLoggingIn ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Verify & Sign In"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
