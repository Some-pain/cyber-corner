import { useState } from "react";
import { AppLayout } from "@/components/layout/app-layout";
import { useRequests } from "@/hooks/use-requests";
import { useI18n } from "@/lib/i18n";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/ui/status-badge";
import { Search, Plus, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

export default function RequestsPage() {
  const { t } = useI18n();
  const { data: requests = [], isLoading } = useRequests();
  const [searchTerm, setSearchTerm] = useState("");

  const filtered = requests.filter(r => 
    r.applicationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.phone.includes(searchTerm)
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold font-display">{t("requests")}</h1>
            <p className="text-muted-foreground">Manage citizen service applications</p>
          </div>
          <Button className="gov-gradient hover-elevate">
            <Plus className="w-4 h-4 mr-2" />
            {t("create_new")}
          </Button>
        </div>

        <Card className="gov-card border-none shadow-md">
          <div className="p-4 border-b border-border bg-secondary/20 flex flex-col sm:flex-row gap-4">
            <div className="relative w-full max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by App No, Name, or Phone..." 
                className="pl-9 bg-background"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-secondary/40">
                <TableRow>
                  <TableHead className="font-semibold">{t("application_no")}</TableHead>
                  <TableHead className="font-semibold">Date</TableHead>
                  <TableHead className="font-semibold">{t("customer_name")}</TableHead>
                  <TableHead className="font-semibold">{t("phone")}</TableHead>
                  <TableHead className="font-semibold">{t("status")}</TableHead>
                  <TableHead className="text-right font-semibold">{t("action")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
                ) : filtered.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No requests found</TableCell></TableRow>
                ) : (
                  filtered.map((req) => (
                    <TableRow key={req.id} className="hover:bg-secondary/20 transition-colors group">
                      <TableCell className="font-medium font-mono text-primary">{req.applicationNumber}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {req.createdAt ? format(new Date(req.createdAt), 'dd MMM yyyy') : '-'}
                      </TableCell>
                      <TableCell className="font-medium">{req.customerName}</TableCell>
                      <TableCell className="text-sm">{req.phone}</TableCell>
                      <TableCell><StatusBadge status={req.status} /></TableCell>
                      <TableCell className="text-right">
                        <Link href={`/requests/${req.id}`}>
                          <Button variant="ghost" size="sm" className="hover:bg-primary/10 hover:text-primary rounded-full group-hover:opacity-100">
                            <Eye className="w-4 h-4 mr-1" /> View
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </AppLayout>
  );
}
