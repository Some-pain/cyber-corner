import { useState } from "react";
import { useRoute } from "wouter";
import { AppLayout } from "@/components/layout/app-layout";
import { useRequest, useUpdateRequest } from "@/hooks/use-requests";
import { useServices } from "@/hooks/use-services";
import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Upload, MessageCircle, Save, IndianRupee, FileText } from "lucide-react";

export default function RequestDetail() {
  const [, params] = useRoute("/requests/:id");
  const id = params?.id ? parseInt(params.id) : null;
  const { t } = useI18n();
  const { toast } = useToast();
  
  const { data: request, isLoading } = useRequest(id);
  const { data: services = [] } = useServices();
  const updateMutation = useUpdateRequest();
  
  const [utr, setUtr] = useState("");
  const [remarks, setRemarks] = useState("");

  if (isLoading) return <AppLayout><div className="p-8 text-center">Loading...</div></AppLayout>;
  if (!request) return <AppLayout><div className="p-8 text-center">Not found</div></AppLayout>;

  const service = services.find(s => s.id === request.serviceId);
  const isPaymentPending = request.status === "VERIFIED" || request.status === "PAYMENT_PENDING";

  const handleStatusChange = async (newStatus: string) => {
    try {
      await updateMutation.mutateAsync({ id: request.id, data: { status: newStatus } });
      toast({ title: "Status updated successfully" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleSaveDetails = async () => {
    try {
      await updateMutation.mutateAsync({ 
        id: request.id, 
        data: { utrNumber: utr || request.utrNumber, remarks: remarks || request.remarks } 
      });
      toast({ title: "Details saved successfully" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const simulateWhatsApp = () => {
    toast({ title: "WhatsApp Message Sent", description: `Notification sent to ${request.phone}` });
  };

  return (
    <AppLayout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => window.history.back()} className="rounded-full">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold font-display">{request.applicationNumber}</h1>
              <StatusBadge status={request.status} />
            </div>
            <p className="text-muted-foreground">Application Details</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Main Info */}
          <div className="md:col-span-2 space-y-6">
            <Card className="gov-card">
              <CardHeader className="bg-secondary/30 border-b border-border pb-4">
                <CardTitle className="text-lg">Customer Information</CardTitle>
              </CardHeader>
              <CardContent className="p-6 grid grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-muted-foreground block mb-1">Name</label>
                  <p className="font-medium text-lg">{request.customerName}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground block mb-1">Phone</label>
                  <p className="font-medium text-lg font-mono">{request.phone}</p>
                </div>
                <div className="col-span-2">
                  <label className="text-sm text-muted-foreground block mb-1">Requested Service</label>
                  <div className="p-3 bg-secondary/20 rounded-lg border border-border flex items-start gap-3">
                    <FileText className="text-primary mt-1" size={20} />
                    <div>
                      <p className="font-semibold">{service?.nameEn || "Unknown Service"}</p>
                      <p className="text-sm text-muted-foreground">{service?.descriptionEn}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="gov-card">
              <CardHeader className="bg-secondary/30 border-b border-border pb-4">
                <CardTitle className="text-lg">Workflow & Remarks</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Internal Remarks</label>
                  <Textarea 
                    defaultValue={request.remarks || ""}
                    onChange={e => setRemarks(e.target.value)}
                    placeholder="Add operational notes here..."
                    className="min-h-[100px] resize-none"
                  />
                </div>
                <div className="flex justify-end">
                  <Button onClick={handleSaveDetails} variant="secondary" className="hover-elevate">
                    <Save className="w-4 h-4 mr-2" /> Save Notes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Sidebar */}
          <div className="space-y-6">
            <Card className="gov-card border-primary/20">
              <CardHeader className="bg-primary/5 border-b border-primary/10 pb-4">
                <CardTitle className="text-lg flex items-center gap-2">
                  <IndianRupee size={18} className="text-primary" /> Payment Info
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground block mb-1">Total Fee</label>
                  <p className="text-3xl font-display font-bold text-foreground">₹{(request.amount / 100).toFixed(2)}</p>
                </div>
                
                {isPaymentPending && (
                  <div className="space-y-2 pt-4 border-t border-border">
                    <label className="text-sm font-medium block">Enter UTR / Ref No</label>
                    <Input 
                      placeholder="e.g. UPI123456789" 
                      defaultValue={request.utrNumber || ""}
                      onChange={e => setUtr(e.target.value)}
                    />
                    <Button onClick={handleSaveDetails} className="w-full mt-2" size="sm">
                      Update Payment Info
                    </Button>
                  </div>
                )}
                
                {request.utrNumber && !isPaymentPending && (
                  <div className="pt-4 border-t border-border">
                    <label className="text-sm text-muted-foreground block mb-1">UTR Number</label>
                    <p className="font-mono bg-secondary/50 p-2 rounded text-sm">{request.utrNumber}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="gov-card">
              <CardHeader className="bg-secondary/30 border-b border-border pb-4">
                <CardTitle className="text-lg">Actions</CardTitle>
              </CardHeader>
              <CardContent className="p-4 flex flex-col gap-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-green-600 hover:text-green-700 hover:bg-green-50"
                  onClick={simulateWhatsApp}
                >
                  <MessageCircle className="w-4 h-4 mr-3" /> Notify Customer
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => toast({ title: "Document upload clicked (simulated)" })}
                >
                  <Upload className="w-4 h-4 mr-3" /> Upload Document
                </Button>
                
                <div className="h-px bg-border my-2"></div>
                
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 px-1">Advance Status To</p>
                
                {request.status === 'SUBMITTED' && (
                  <Button className="w-full gov-gradient" onClick={() => handleStatusChange('VERIFIED')}>
                    Verify Application
                  </Button>
                )}
                {request.status === 'VERIFIED' && (
                  <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-white" onClick={() => handleStatusChange('PROCESSING')}>
                    Mark as Paid & Process
                  </Button>
                )}
                {request.status === 'PROCESSING' && (
                  <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white" onClick={() => handleStatusChange('COMPLETED')}>
                    Complete Work
                  </Button>
                )}
                {request.status === 'COMPLETED' && (
                  <Button className="w-full bg-teal-600 hover:bg-teal-700 text-white" onClick={() => handleStatusChange('DELIVERED')}>
                    Deliver to Customer
                  </Button>
                )}
                {request.status === 'DELIVERED' && (
                  <div className="text-center p-3 bg-green-50 text-green-700 rounded-lg text-sm font-medium border border-green-200">
                    Workflow Completed
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
