import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

export default function Login() {
  // ================= STATES =================
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [timer, setTimer] = useState(0);
  const [loading, setLoading] = useState(false);

  // ================= SEND OTP =================
  const sendOtp = async () => {
    if (!phone) {
      alert("Enter phone number");
      return;
    }

    try {
      setLoading(true);

      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });

      const data = await res.json();

      if (data.success) {
        setOtpSent(true);
        setTimer(60); // ⏱️ start resend timer
      } else {
        alert(data.error || "OTP send failed");
      }
    } catch (err) {
      console.error(err);
      alert("Server error");
    } finally {
      setLoading(false);
    }
  };

  // ================= VERIFY OTP =================
  const verifyOtp = async () => {
    if (!otp) {
      alert("Enter OTP");
      return;
    }

    try {
      const res = await fetch("/api/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, otp }),
      });

      const data = await res.json();

      if (data.verified) {
        alert("Login successful ✅");
        // 👉 later: redirect / save JWT
      } else {
        alert(data.error || "Invalid OTP");
      }
    } catch (err) {
      console.error(err);
      alert("Verification failed");
    }
  };

  // ================= TIMER LOGIC =================
  useEffect(() => {
    if (timer <= 0) return;

    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [timer]);

  // ================= UI =================
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="w-full max-w-sm rounded-lg border p-6 space-y-4">
        <h2 className="text-xl font-semibold text-center">CSC Login</h2>

        {/* PHONE INPUT */}
        <input
          type="tel"
          placeholder="Enter mobile number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="w-full rounded-md border px-3 py-2"
        />

        {/* SEND / RESEND OTP BUTTON */}
        <Button
          onClick={sendOtp}
          disabled={timer > 0 || loading}
          className="w-full"
        >
          {loading
            ? "Sending..."
            : timer > 0
              ? `Resend OTP in ${timer}s`
              : otpSent
                ? "Resend OTP"
                : "Send OTP"}
        </Button>

        {/* OTP INPUT + VERIFY */}
        {otpSent && (
          <>
            <input
              type="text"
              placeholder="Enter OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="w-full rounded-md border px-3 py-2"
            />

            <Button onClick={verifyOtp} className="w-full">
              Verify OTP
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
