import { create } from 'zustand';

type Language = 'en' | 'bn';

interface I18nStore {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations.en) => string;
}

const translations = {
  en: {
    dashboard: "Dashboard",
    requests: "Requests",
    services: "Services",
    notices: "Notices",
    users: "Users",
    settings: "Settings",
    login: "Login",
    logout: "Logout",
    welcome: "Welcome to NETZONE",
    digital_service_center: "Digital Service Center",
    total_requests: "Total Requests",
    pending_actions: "Pending Actions",
    revenue: "Total Revenue",
    recent_activity: "Recent Activity",
    application_no: "App No.",
    customer_name: "Customer Name",
    phone: "Phone",
    service: "Service",
    status: "Status",
    amount: "Amount",
    action: "Action",
    create_new: "Create New",
    search: "Search...",
    save: "Save",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    submit: "Submit",
    verify: "Verify",
    process: "Process",
    complete: "Complete",
    deliver: "Deliver",
    upload_document: "Upload Document",
    enter_utr: "Enter UTR Number",
    payment_method: "Payment Method",
    remarks: "Remarks",
    send_whatsapp: "Send WhatsApp",
    english: "English",
    bengali: "বাংলা",
  },
  bn: {
    dashboard: "ড্যাশবোর্ড",
    requests: "অনুরোধসমূহ",
    services: "পরিষেবাসমূহ",
    notices: "বিজ্ঞপ্তি",
    users: "ব্যবহারকারী",
    settings: "সেটিংস",
    login: "লগইন",
    logout: "লগআউট",
    welcome: "NETZONE এ স্বাগতম",
    digital_service_center: "ডিজিটাল সার্ভিস সেন্টার",
    total_requests: "মোট অনুরোধ",
    pending_actions: "অপেক্ষমান কাজ",
    revenue: "মোট আয়",
    recent_activity: "সাম্প্রতিক কার্যকলাপ",
    application_no: "অ্যাপ্লিকেশন নং",
    customer_name: "গ্রাহকের নাম",
    phone: "ফোন",
    service: "পরিষেবা",
    status: "অবস্থা",
    amount: "পরিমাণ",
    action: "পদক্ষেপ",
    create_new: "নতুন তৈরি করুন",
    search: "অনুসন্ধান...",
    save: "সংরক্ষণ করুন",
    cancel: "বাতিল করুন",
    edit: "সম্পাদনা করুন",
    delete: "মুছে ফেলুন",
    submit: "জমা দিন",
    verify: "যাচাই করুন",
    process: "প্রক্রিয়া করুন",
    complete: "সম্পূর্ণ করুন",
    deliver: "বিতরণ করুন",
    upload_document: "নথি আপলোড করুন",
    enter_utr: "UTR নম্বর লিখুন",
    payment_method: "পেমেন্ট পদ্ধতি",
    remarks: "মন্তব্য",
    send_whatsapp: "হোয়াটসঅ্যাপ পাঠান",
    english: "English",
    bengali: "বাংলা",
  }
};

export const useI18n = create<I18nStore>((set, get) => ({
  language: (localStorage.getItem('netzone_lang') as Language) || 'en',
  setLanguage: (lang: Language) => {
    localStorage.setItem('netzone_lang', lang);
    set({ language: lang });
  },
  t: (key: keyof typeof translations.en) => {
    const lang = get().language;
    return translations[lang][key] || translations['en'][key] || key;
  }
}));
