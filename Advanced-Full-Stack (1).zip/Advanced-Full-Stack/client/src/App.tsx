import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Import pages
import Login from "./pages/auth/login";
import Dashboard from "./pages/dashboard";
import RequestsPage from "./pages/requests";
import RequestDetail from "./pages/requests/[id]";
import ServicesPage from "./pages/services";
import NoticesPage from "./pages/notices";
import UsersPage from "./pages/users";
import { useAuth } from "./hooks/use-auth";
import { Loader2 } from "lucide-react";

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="h-screen w-screen flex items-center justify-center bg-background"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }
  
  if (!user) {
    return <Redirect to="/login" />;
  }
  
  return <Component {...rest} />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => <Redirect to="/dashboard" />} />
      <Route path="/login" component={Login} />
      
      {/* Protected Routes */}
      <Route path="/dashboard"><ProtectedRoute component={Dashboard} /></Route>
      <Route path="/requests"><ProtectedRoute component={RequestsPage} /></Route>
      <Route path="/requests/:id"><ProtectedRoute component={RequestDetail} /></Route>
      <Route path="/services"><ProtectedRoute component={ServicesPage} /></Route>
      <Route path="/notices"><ProtectedRoute component={NoticesPage} /></Route>
      <Route path="/users"><ProtectedRoute component={UsersPage} /></Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
