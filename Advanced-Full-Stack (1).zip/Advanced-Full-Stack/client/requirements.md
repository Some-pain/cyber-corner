## Packages
recharts | Dashboard analytics charts and data visualization
date-fns | Human-readable date formatting
zustand | Lightweight state management for UI states (sidebar, language)

## Notes
- API expects standard JSON REST requests.
- Authentication uses HTTP-only cookies (session based).
- File upload is a simulated POST to /api/upload returning `{ url: string }`.
- WhatsApp integration is simulated via frontend UI buttons calling no-op or placeholder endpoints.
- Role-based access control is handled mostly on frontend by hiding UI elements, assuming backend enforces it.
